

<?php $__env->startSection('title'); ?>
    Pengeluaran | Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pengeluaran'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->
            <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->

                <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- / Navbar -->

                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->

                    <div class="container-fluid flex-grow-1 container-p-y">
                        <!-- Examples -->
                        <div class="row mb-5">
                            <div class="col mb-3">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-6">
                                            <h5 class="card-header">
                                                List Pengeluaran
                                            </h5>
                                        </div>
                                        <div class="col-6 d-flex justify-content-end align-items-center">
                                            <a id="addDataOutcomeButton" href="#"
                                                class="btn btn-outline-secondary me-2">Tambah Data
                                            </a>
                                            <form id="pdfForm" action="<?php echo e(route('reportJob')); ?>" method="GET" target="_blank">
                                                <input type="hidden" name="job" id="jobInput" value="<?php echo e($title); ?>">
                                                <button type="submit" class="btn btn-outline-secondary me-2">Cetak Laporan</button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="row mt-2">
                                            <div class="table-responsive text-nowrap" id="table-content">
                                                <table class="table table-striped" id="dataTable">
                                                    <thead id="tableHead">
                                                        <tr>
                                                            <?php $__currentLoopData = $columnsSubset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <th><?php echo e($column); ?></th>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <th>Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="table-border-bottom-0" id="tableOutcomeBody">
                                                        <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr id="outcome_<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>">
                                                                <?php $__currentLoopData = $columnsSubset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <td><?php echo e($item->$column); ?></td>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <td>
                                                                    <div class="dropdown">
                                                                        <button type="button"
                                                                            class="btn p-0 dropdown-toggle hide-arrow"
                                                                            data-bs-toggle="dropdown">
                                                                            <i class="bx bx-dots-vertical-rounded"></i>
                                                                        </button>
                                                                        <div class="dropdown-menu">
                                                                            <a class="dropdown-item edit-outcome-button"
                                                                                href="javascript:void(0);"
                                                                                data-id="<?php echo e($item->id); ?>">
                                                                                <i class="bx bx-edit-alt me-1"></i> Edit
                                                                            </a>
                                                                            <a class="dropdown-item delete-outcome-button"
                                                                                href="javascript:void(0);"
                                                                                data-id="<?php echo e($item->id); ?>">
                                                                                <i class="bx bx-trash me-1"></i> Delete
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                                <div class="row justify-content-center mt-5 mx-3">
                                                    <?php echo $query->withQueryString()->links('pagination::bootstrap-5'); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Examples -->
                    </div>
                    <!-- / Content -->

                    <!-- Footer -->
                    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>
    </div>
    <!-- / Layout wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\gawean\aiman cell\app\resources\views/admin/pengeluaran.blade.php ENDPATH**/ ?>