<!-- Modal for adding new data -->
<div class="modal fade" id="addDataSellModal" tabindex="-1" aria-labelledby="addDataSellModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="addDataSellForm" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="addDataSellModalLabel">Jual Barang</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php $__currentLoopData = $columnsSubset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $lowerColumn = strtolower($column);
                        ?>
                        <?php if($lowerColumn === 'gambar'): ?>
                            <div class="mb-3">
                                <label for="<?php echo e($column); ?>" class="form-label"><?php echo e($column); ?></label>
                                <input type="file" class="form-control" id="<?php echo e($column); ?>" name="<?php echo e($column); ?>" required>
                                <div class="alert alert-danger mt-2 d-none" role="alert" id="alert-<?php echo e($column); ?>"></div>
                            </div>
                        <?php elseif($lowerColumn === 'deskripsi'): ?>
                            <div class="mb-3">
                                <label for="<?php echo e($column); ?>" class="form-label"><?php echo e($column); ?></label>
                                <textarea class="form-control" id="<?php echo e($column); ?>" name="<?php echo e($column); ?>" rows="4" required></textarea>
                                <div class="alert alert-danger mt-2 d-none" role="alert" id="alert-<?php echo e($column); ?>"></div>
                            </div>
                        <?php else: ?>
                            <div class="mb-3">
                                <label for="<?php echo e($column); ?>" class="form-label"><?php echo e($column); ?></label>
                                <input type="text" class="form-control" id="<?php echo e($column); ?>" name="<?php echo e($column); ?>" required>
                                <div class="alert alert-danger mt-2 d-none" role="alert" id="alert-<?php echo e($column); ?>"></div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Jual</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\gawean\aiman cell\app\resources\views/components/sell-modal-create.blade.php ENDPATH**/ ?>