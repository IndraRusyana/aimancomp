

<?php $__env->startSection('title'); ?>
    Manajemen Store || Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('store'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->
            <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->

                <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- / Navbar -->

                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->

                    <div class="container-fluid flex-grow-1 container-p-y">
                        <div class="row">
                            <div class="col-6 mx-auto">
                                <div class="card mb-4">
                                    <div class="row">
                                        <div class="col-10">
                                            <h5 class="card-header">Update Data</h5>
                                        </div>
                                    </div>

                                    <div class="card-body">
                                        <div class="row justify-content-center" id="productsContainer">
                                            <form enctype="multipart/form-data" method="post" action="<?php echo e(route('store.update', $query->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <?php $__currentLoopData = $columnsSubset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($column === 'gambar'): ?>
                                                        <div class="mb-3">
                                                            <label for="<?php echo e($column); ?>" class="form-label"><?php echo e($column); ?></label>
                                                            <img src="<?php echo e(asset('storage/'.$query->gambar)); ?>" class="img-thumbnail mb-2" id="existing_<?php echo e($column); ?>" alt="Existing Image" height="100" width="250">
                                                            <input type="file" class="form-control" id="<?php echo e($column); ?>" name="<?php echo e($column); ?>">
                                                            <input type="hidden" name="existing_<?php echo e($column); ?>" value="<?php echo e($query->gambar); ?>">
                                                            <div class="alert alert-danger mt-2 d-none" role="alert" id="alert-<?php echo e($column); ?>"></div>
                                                        </div>
                                                    <?php elseif($column === 'deskripsi'): ?>
                                                        <div class="mb-3">
                                                            <label for="<?php echo e($column); ?>" class="form-label"><?php echo e($column); ?></label>
                                                            <textarea class="form-control" id="<?php echo e($column); ?>" name="<?php echo e($column); ?>" rows="4" required><?php echo e($query->$column); ?></textarea>
                                                            <div class="alert alert-danger mt-2 d-none" role="alert" id="alert-<?php echo e($column); ?>"></div>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="mb-3">
                                                            <label for="<?php echo e($column); ?>" class="form-label"><?php echo e($column); ?></label>
                                                            <input type="text" class="form-control" id="<?php echo e($column); ?>" name="<?php echo e($column); ?>" value="<?php echo e($query->$column); ?>" required>
                                                            <div class="alert alert-danger mt-2 d-none" role="alert" id="alert-<?php echo e($column); ?>"></div>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <div class="card-footer">
                                                    <div class="row">
                                                        <div class="col-6 mx-auto">
                                                            <a href="/admin/store" class="btn btn-secondary">Back</a>
                                                            <button type="submit" class="btn btn-primary">Save changes</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- / Content -->

                    <!-- Footer -->
                    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>
    </div>
    <!-- / Layout wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\gawean\aiman cell\app\resources\views/components/sell-modal-edit.blade.php ENDPATH**/ ?>