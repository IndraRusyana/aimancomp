

<?php $__env->startSection('title'); ?>
    Keanggotaan | Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('keanggotaan'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->
            <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->

                <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- / Navbar -->

                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->

                    <div class="container-fluid flex-grow-1 container-p-y">
                        <h4 class="fw-bold py-3 mb-4"> Table <div id="tableTitle" class="d-inline">Admin</div></h4>
                        <div class="card">
                            <h6 class="card-header">
                                <ul id="dataType" class="nav nav-pills mb-3" role="tablist">
                                    <li class="nav-item" data-value='{"path":"keanggotaan","menu":"admins"}'>
                                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'admins.index' ? 'active' : ''); ?>"  href="<?php echo e(route('admins.index')); ?>">
                                            Admin
                                        </a>
                                    </li>
                                    <li class="nav-item" data-value='{"path":"keanggotaan","menu":"investors"}'>
                                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'investors.index' ? 'active' : ''); ?>"  href="<?php echo e(route('investors.index')); ?>">
                                            Investor
                                        </a>
                                    </li>
                                    <li class="nav-item" data-value='{"path":"keanggotaan","menu":"owners"}'>
                                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'owners.index' ? 'active' : ''); ?>" href="<?php echo e(route('owners.index')); ?>">
                                            Owner
                                        </a>
                                    </li>
                                </ul>
                            </h6>
                            <div class="table-responsive text-nowrap" id="table-content">
                                <table class="table table-striped" id="dataTable">
                                    <thead id="tableHead">
                                        <tr >
                                            <?php $__currentLoopData = $columnsSubset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th><?php echo e($column); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(auth()->user()->isOwner()): ?>
                                            <th>Actions</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody class="table-border-bottom-0" id="tableBody">
                                        <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr id="index_<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>">
                                                <?php $__currentLoopData = $columnsSubset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td><?php echo e($item->$column); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(auth()->user()->isOwner()): ?>
                                                <td>
                                                    <div class="dropdown">
                                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                                            <i class="bx bx-dots-vertical-rounded"></i>
                                                        </button>
                                                        <div class="dropdown-menu">
                                                            <a class="dropdown-item edit-button" href="javascript:void(0);" data-id="<?php echo e($item->id); ?>">
                                                                <i class="bx bx-edit-alt me-1"></i> Edit
                                                            </a>
                                                            <a class="dropdown-item delete-button" href="javascript:void(0);" data-id="<?php echo e($item->id); ?>">
                                                                <i class="bx bx-trash me-1"></i> Delete
                                                            </a>
                                                        </div>
                                                    </div>
                                                </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <?php if(auth()->user()->isOwner()): ?>
                                    <tfoot class="">
                                        <tr>
                                            <th colspan="5">
                                                <a class="btn btn-outline-primary my-3" style="font-size:12px;"
                                                    href="#" id="addDataButton">
                                                    Tambah Data
                                                </a>
                                            </th>
                                        </tr>
                                    </tfoot>
                                    <?php endif; ?>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- / Content -->
                </div>
                <!-- Footer -->
                <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- / Footer -->

                <div class="content-backdrop fade"></div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>
    </div>
    <!-- / Layout wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\gawean\aiman cell\app\resources\views/admin/keanggotaan.blade.php ENDPATH**/ ?>