<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pekerjaan PDF</title>
    <style>
        /* Tambahkan styling sesuai kebutuhan */
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            margin: 20px;
        }
        .heading {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .section {
            margin-bottom: 20px;
        }
        .section h2 {
            font-size: 20px;
            margin-bottom: 10px;
        }
        .section table {
            width: 100%;
            border-collapse: collapse;
        }
        .section table, .section th, .section td {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="heading">Laporan <?php echo e($job); ?></h1>
        <div class="section">
            <h2>Periode Laporan: Semua Waktu</h2>
        </div>

        <div class="section" >
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <?php $__currentLoopData = $columnsSubset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($column); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $no = 1;
                    ?>
                    <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no); ?></td>
                            <?php $__currentLoopData = $columnsSubset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($column === 'harga' || $column === 'nominal' || $column === 'modal' || $column === 'harga_awal' || $column === 'harga_jual'): ?>
                                    <td>Rp. <?php echo number_format($item->$column,0,',','.'); ?></td>
                                <?php else: ?> {
                                    <td><?php echo e($item->$column); ?></td>
                                }
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php
                        $no++;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <p>Total : Rp. <?php echo number_format($total,0,',','.'); ?></p>
    </div>
</body>
</html>
<?php /**PATH D:\gawean\aiman cell\app\resources\views/pdf/laporan-pekerjaan.blade.php ENDPATH**/ ?>