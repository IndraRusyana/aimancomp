<!-- Footer -->
<footer class="content-footer footer bg-footer-theme">
    <div
        class="container-fluid d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            ©
            <script>
                document.write(new Date().getFullYear());
            </script>
           Aiman Comp
        </div>
        <div>
            Support By
            <a href="" class="footer-link me-4"
                target="_blank">Myklikjitu</a>
        </div>
    </div>
</footer>
<!-- / Footer --><?php /**PATH D:\gawean\aiman cell\app\resources\views/components/footer.blade.php ENDPATH**/ ?>